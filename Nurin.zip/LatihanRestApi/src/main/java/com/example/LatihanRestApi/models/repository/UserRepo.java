package com.example.LatihanRestApi.models.repository;

import com.example.LatihanRestApi.models.entity.User;
import org.springframework.data.repository.CrudRepository;

import java.util.List;

public interface UserRepo extends CrudRepository<User, Long> {
    //List<User> findByNameContains(String username);
}
