package com.example.LatihanRestApi.services;

import com.example.LatihanRestApi.models.entity.User;
import com.example.LatihanRestApi.models.repository.UserRepo;
import jakarta.transaction.Transactional;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;


@Service
@Transactional

public class UserService {


    @Autowired
    private UserRepo userRepo;

    public User save(User user) {
        return userRepo.save(user);
    }

    public void removeOne(Long id) {
        userRepo.deleteById(id);
    }

    public User find(Long id) {
       return userRepo.findById(id).get() ;

    }

    public List<User> findAll(){
        return userRepo.findAll();
    }

    //public user findOne(long)

}