package com.example.LatihanRestApi;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class LatihanRestApiApplication {

	public static void main(String[] args) {

		SpringApplication.run(LatihanRestApiApplication.class, args);
	}

}
