package com.example.LatihanRestApi.controllers;

import com.example.LatihanRestApi.models.entity.User;
import com.example.LatihanRestApi.models.repository.UserRepo;
import com.example.LatihanRestApi.services.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;


@RestController
@RequestMapping("/user")

public class UserController {

    @Autowired
    private UserRepo uRepo;

    @Autowired
    UserService userService;

    @PostMapping("/registration")
    public User create(@RequestBody User user){
        return userService.save(user);
    }

    @GetMapping
    public List<User> findAll(){
        return userService.findAll();
    }


    @DeleteMapping("/{id}")
    public void removeOne(@PathVariable("id") Long id){
        UserService.removeOne(id);
    }



 /*   @GetMapping("find/{id}")
    public Product findOne(@PathVariable("id") Long id){
        return ProdService.findOne(id);
    }

    */


}
