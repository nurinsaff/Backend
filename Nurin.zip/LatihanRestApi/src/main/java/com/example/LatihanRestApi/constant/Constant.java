package com.example.LatihanRestApi.constant;

public class Constant {

        public static final long Max_Balance = 10000000;
        public static final long Min_Balance = 10000;
        public static final long Max_Transaction_Amount = 1000000;
        public static final long Max_Transaction_Amount_With_KTP = 5000000;
        public static final long Min_Transaction_Amount = 10000;
        public static final long  Max_Topup = 10000000;
        public static final double Transaction_Tax = 0.125;

}
