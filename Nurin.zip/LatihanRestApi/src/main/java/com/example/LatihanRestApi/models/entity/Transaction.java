package com.example.LatihanRestApi.models.entity;

import jakarta.persistence.*;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
@Entity
@Table(name = "tb_transaction")

    public class Transaction {

        @Id
        @Column(name="transaction_id")
        @GeneratedValue(strategy = GenerationType.AUTO)
        private long id;

    /*
    @Column(name="saldo", length = 100 )
    private Long saldo;

    @Column(name="top_up", length = 100)
    private Long toUp;

    @Column(name="kredit", length = 100)
    private Long kredit;

     */
    }
